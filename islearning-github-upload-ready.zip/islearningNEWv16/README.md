# ISLearning — Figma frontend with original backend

This project uses the **new frontend from `islearningnewfrontend(2).zip`** as the frontend source and the original ISLearning Python/MySQL backend. It does not copy the old system's frontend into the new frontend.

## Important changes

- New frontend source/screens are retained from the supplied newfrontend project.
- Removed preloaded/demo materials, demo folders, reviewers, quiz history, and notifications from initial app state. Users start with an empty materials library.
- Sign-in and account creation call the real backend rather than a mock timeout.
- New registrations save the submitted student profile in MySQL. Accounts with a completed profile go directly to Home.
- On successful login, the backend repairs the completion flag for legacy accounts whose first/last name, course, and student ID already exist, so returning students are not repeatedly sent through profile setup.
- Profile setup saves to the backend.
- Folder create/rename/delete/move operations are connected to the backend.
- Upload UI selects a real local file and uploads it to the backend.
- Practice quiz screen allows selecting up to five uploaded materials and sends question count, type, and difficulty to the backend generator.
- No `.env` secrets or uploaded user files are included in this package.

## Run backend

1. Install Python 3.10+.
2. Copy `backend/.env.example` to `backend/.env` and set your MySQL credentials and AI provider key.
3. Create the configured MySQL database (default `islearning`).
4. From `backend`, run `setup.bat` on Windows or install `requirements.txt` with pip.
5. Start with `python run.py` or `start.bat`.

The backend creates/migrates its required tables at startup. `RESET_MYSQL_DATA.sql` is destructive; do not run it against a database you want to keep.

## Run frontend

1. Install Node.js 20+ and pnpm (or use npm to install dependencies from `package.json`).
2. In `frontend`, install dependencies (`pnpm install`).
3. Copy `.env.example` to `.env` if you need to change the backend URL.
4. Run `pnpm dev` and open the Vite URL shown in the terminal.

## Validation note

The backend file passes Python syntax compilation. A production frontend build and live MySQL/AI end-to-end tests could not be completed in this environment; configure your database and AI credentials and test upload, document preview, folder actions, reviewer generation, quiz generation, and profile/settings in your local setup before production use.

## Practice quiz and generation-screen updates

- The practice quiz screen now has a **Select Materials** button. The picker groups uploaded materials under `My Materials` and their folders; folders can be expanded to browse their contents. The main form shows only selected materials and enforces the five-material limit.
- Question types are multi-select checkboxes, so a single quiz generation can combine any selected types. The frontend maps Coding Analysis to the backend's `code-analysis` type.
- Reviewer generation uses the backend `/api/reviewers` endpoint and displays the existing animated generating screen while the request is running.
- Quiz generation navigates to the same animated generating screen, submits all selected material IDs, question types, count, and difficulty to `/api/quizzes/generate`, then opens the generated quiz.
- Generation failures show an error toast and return to the relevant form.

The frontend TypeScript/TSX sources were transpiled for syntax validation and the Python backend passed `py_compile`. A live database/AI integration test and full Vite production build still require the project's installed dependencies and configured environment.

## Saved quizzes and offline content

- Profile learning shortcuts now focus on **Saved Quizzes** and **Saved Reviewers**; My Materials and My Progress were removed from that profile menu.
- Generated quizzes are retained in a per-user browser local-storage cache. The Saved Quizzes screen lets a learner reopen/take a quiz again, save or unsave it, and permanently delete it. Quizzes remain listed after refresh until deleted.
- The quiz-taking screen has a Save button. Reviewer screens have a Save/ Saved control; saved reviewers and quiz content are cached locally for offline access on the same browser/device.
- The Practice Quiz shortcut opens the quiz-generation form directly, including when no quizzes exist yet. The form also links to generated/saved quizzes.
- Offline content is device/browser-local and is not automatically synchronized between different browsers or devices. Clearing browser storage can remove this local cache.
