@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -m pip install -r requirements.txt
) else (
  python -m pip install -r requirements.txt
)
if not exist ".env" copy ".env.example" ".env" >nul
 echo.
echo Gemini setup complete.
echo Edit backend\.env and put your GEMINI_API_KEY there.
echo Then run start_backend.bat
echo.
pause
