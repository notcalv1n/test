@echo off
setlocal
where ollama >nul 2>nul
if errorlevel 1 (
  echo Ollama is not installed or is not on PATH.
  echo Install it from https://ollama.com/download/windows and reopen this terminal.
  pause
  exit /b 1
)
echo Downloading local fallback model qwen2.5:3b...
ollama pull qwen2.5:3b
if errorlevel 1 (
  echo Model download failed. Check your internet connection and available disk space.
  pause
  exit /b 1
)
echo.
echo Local AI fallback is ready. Keep Ollama running while using ISLearning.
echo Verify with: ollama run qwen2.5:3b "Reply with the word ready"
pause
